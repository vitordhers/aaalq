export enum Algorithms {
  HS256 = 'HS256',
  ES256 = 'ES256',
  ES384 = 'ES384',
  ES512 = 'ES512',
}
